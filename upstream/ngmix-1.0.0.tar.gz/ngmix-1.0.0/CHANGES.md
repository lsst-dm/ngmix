v0.9.0
------

first real version cut, mainly in anticipation for use in
the LSST DM stack.

Code is python3 compatible.
